import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { ConfirmEqualValidatorDirective } from './shared/confirm-equal-validator.directive';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContactUSComponent } from './contact-us/contact-us.component';
import { FDRATESComponent } from './fd-rates/fd-rates.component';
import { LOGINPAGEComponent } from './login-page/login-page.component';
import { REGISTERPAGEComponent } from './register-page/register-page.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HomeComponent } from './home/home.component';
import { LoggedInComponent } from './login-page/logged-in/logged-in.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import {ApproveTransactionComponent} from './adminpage/approve-transaction/approve-transaction.component';
import {CreateAccountComponent} from './adminpage/create-account/create-account.component';
import {DeleteAccountComponent} from './adminpage/delete-account/delete-account.component';
import {UserComponent} from './adminpage/user/user.component';
import {ViewTransactionComponent} from './adminpage/view-transaction/view-transaction.component';

@NgModule({
    declarations: [
        AppComponent,
        routingComponents,
        ContactUSComponent,
        FDRATESComponent,
        LOGINPAGEComponent,
        REGISTERPAGEComponent,
        ConfirmEqualValidatorDirective,
        HomeComponent,
        LoggedInComponent,
        AdminpageComponent,
        ApproveTransactionComponent,
        CreateAccountComponent,
        DeleteAccountComponent,
        UserComponent,
        ViewTransactionComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        AppRoutingModule,
        NgbModule
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }



