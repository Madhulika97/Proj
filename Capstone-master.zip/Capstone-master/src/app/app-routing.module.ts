import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FDRATESComponent } from './fd-rates/fd-rates.component';
import { ContactUSComponent } from './contact-us/contact-us.component';
import { LOGINPAGEComponent} from './login-page/login-page.component';
import { REGISTERPAGEComponent} from './register-page/register-page.component';
import { HomeComponent} from './home/home.component';
import { LoggedInComponent} from './login-page/logged-in/logged-in.component';
import { AdminpageComponent} from './adminpage/adminpage.component';
import { CreateAccountComponent } from './adminpage/create-account/create-account.component';
import { ViewTransactionComponent } from './adminpage/view-transaction/view-transaction.component';
import { ApproveTransactionComponent } from './adminpage/approve-transaction/approve-transaction.component';
import { DeleteAccountComponent } from './adminpage/delete-account/delete-account.component';
import { UserComponent } from './adminpage/user/user.component';
import { AppComponent } from './app.component';

const routes: Routes = [
  {path : '', redirectTo : '/home', pathMatch :'full'},
  {path : 'login-page', component : LOGINPAGEComponent},
  {path : 'register-page', component : REGISTERPAGEComponent },
  { path : 'loggedIn', component:LoggedInComponent},
  {path : 'contact-us', component : ContactUSComponent},
  {path : 'fd-rates' , component : FDRATESComponent},
  {path : 'home' , component : HomeComponent},
  {path : 'adminpage' ,component : AdminpageComponent},
  {path : 'create-account', component: CreateAccountComponent},
  {path : 'view-transaction', component: ViewTransactionComponent},
  {path : 'approve-transaction', component:ApproveTransactionComponent},
  {path : 'delete-account', component:DeleteAccountComponent},
  {path : 'user', component:UserComponent}
,
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [AdminpageComponent,HomeComponent,LOGINPAGEComponent,REGISTERPAGEComponent,
                                  FDRATESComponent,ContactUSComponent,LoggedInComponent,CreateAccountComponent,
                                  DeleteAccountComponent,ViewTransactionComponent,ApproveTransactionComponent]