import {Http} from '@angular/http';

export class BankService{
    constructor(private _httpService: Http){

    }
}