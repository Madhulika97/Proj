export class bank_customer{
    loginId: Number;
    accountNumber: String;
    address: String;
    email: String;
    fullName: String;
    password: String;
    phoneNumber: Number;
}