import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FDRATESComponent } from './fd-rates/fd-rates.component';
import { ContactUSComponent } from './contact-us/contact-us.component';
import { LOGINPAGEComponent} from './login-page/login-page.component';
import { REGISTERPAGEComponent} from './register-page/register-page.component';
import {HomeComponent} from './home/home.component';
import { LoggedInComponent} from './login-page/logged-in/logged-in.component';

const routes: Routes = [
  {path : 'login-page', component : LOGINPAGEComponent},
  {path : 'register-page', component : REGISTERPAGEComponent },
  { path : 'loggedIn', component:LoggedInComponent},
  {path : 'contact-us', component : ContactUSComponent},
  {path : 'fd-rates' , component : FDRATESComponent},
  {path : 'home' , component : HomeComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [HomeComponent,LOGINPAGEComponent,REGISTERPAGEComponent,FDRATESComponent,ContactUSComponent,LoggedInComponent]