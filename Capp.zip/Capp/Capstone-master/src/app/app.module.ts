import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { ConfirmEqualValidatorDirective } from './shared/confirm-equal-validator.directive';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContactUSComponent } from './contact-us/contact-us.component';
import { FDRATESComponent } from './fd-rates/fd-rates.component';
import { LOGINPAGEComponent } from './login-page/login-page.component';
import { REGISTERPAGEComponent } from './register-page/register-page.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
    declarations: [
        AppComponent,
        routingComponents,
        ContactUSComponent,
        FDRATESComponent,
        LOGINPAGEComponent,
        REGISTERPAGEComponent,
        ConfirmEqualValidatorDirective
    ],
    imports: [
        BrowserModule,
        FormsModule,
        AppRoutingModule,
        NgbModule
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }



