import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginsuccessful',
  templateUrl: './loginsuccessful.component.html',
  styleUrls: ['./loginsuccessful.component.css']
})
export class LoginsuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
